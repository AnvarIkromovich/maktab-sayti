from django.contrib import admin

from .models import *

admin.site.register(AboutSchool)
admin.site.register(Managements)
admin.site.register(Staff)
admin.site.register(Author)
admin.site.register(News)
admin.site.register(Gallery)
admin.site.register(Contact)
admin.site.register(Banner)
admin.site.register(Statistics)
admin.site.register(Features)
admin.site.register(Courses)
admin.site.register(Students)


